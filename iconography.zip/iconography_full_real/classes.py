# classes.py
# Master hard-coded iconography class list (35 classes)

CLASSES = [
    "shiva_standing",
    "shiva_nataraja",
    "shiva_lingam",
    "ardhanarishvara",
    "bhairava",

    "vishnu_standing",
    "varaha",
    "narasimha",
    "rama",
    "krishna_venugopala",
    "balakrishna",
    "vithoba",
    "shrinathji",

    "ganesha_standing",
    "ganesha_sitting",

    "durga_mahishasuramardini",
    "kali",
    "chamunda",
    "bhadrakali",
    "tripurasundari",
    "bhavani",

    "lakshmi",
    "saraswati",
    "parvati",
    "surya",
    "hanuman",
    "nandi",
    "garuda",

    "mahavira",
    "buddha_meditating",
    "skanda_murugan",
    "mayura",
    "shesha"
]

