#!/usr/bin/env python3
"""
download-images.py  (Updated for 35-class Iconography Dataset)

Features:
 - Uses classes.txt (35 iconography classes)
 - Downloads from Wikimedia Commons + MET Museum
 - Proper User-Agent (required by Wikimedia)
 - Saves into raw/<class>/ folders
 - Logs provenance to provenance.csv
"""

import argparse
import csv
import os
import time
from pathlib import Path
from urllib.parse import unquote

import requests
from PIL import Image
from io import BytesIO
from tqdm import tqdm


# ------------------------------------------------------------
# REQUIRED USER-AGENT (Wikimedia blocks without this)
# ------------------------------------------------------------
HEADERS = {
    "User-Agent": "IconographyResearchBot/1.0 (contact: your-email@example.com)"
}

# Wikimedia API
WIKI_API = "https://commons.wikimedia.org/w/api.php"

# MET Museum API
MET_SEARCH = "https://collectionapi.metmuseum.org/public/collection/v1/search"
MET_OBJECT = "https://collectionapi.metmuseum.org/public/collection/v1/objects/"

# Allowed licenses (simple match)
ALLOWED_LICENSE_KEYWORDS = [
    "public domain",
    "cc-by",
    "cc-by-sa",
    "creative commons"
]


# ------------------------------------------------------------
# Utilities
# ------------------------------------------------------------
def slugify(text: str) -> str:
    """Convert class name to a safe folder-friendly string."""
    return "".join(c if c.isalnum() else "_" for c in text.lower())


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def is_license_allowed(license_string: str) -> bool:
    if not license_string:
        return False
    ls = license_string.lower()
    return any(k in ls for k in ALLOWED_LICENSE_KEYWORDS)


def save_image_bytes(img_bytes: bytes, path: Path):
    ensure_dir(path.parent)
    with open(path, "wb") as f:
        f.write(img_bytes)


def safe_request(session, url, params=None, retries=3):
    for attempt in range(retries):
        try:
            r = session.get(
                url,
                params=params,
                headers=HEADERS,
                timeout=30
            )
            r.raise_for_status()
            return r
        except Exception:
            if attempt == retries - 1:
                return None
            time.sleep(1 + attempt * 1.5)  # mild backoff
    return None


# ------------------------------------------------------------
# Wikimedia Commons Downloader
# ------------------------------------------------------------
def download_wikimedia_images(class_name: str, limit: int):
    results = []
    session = requests.Session()

    # Try category search
    params = {
        "action": "query",
        "list": "categorymembers",
        "cmtitle": f"Category:{class_name}",
        "cmlimit": min(limit, 500),
        "format": "json",
    }

    r = safe_request(session, WIKI_API, params=params)
    members = []
    if r:
        data = r.json()
        members = data.get("query", {}).get("categorymembers", [])

    # Fallback to text search
    if not members:
        params = {
            "action": "query",
            "list": "search",
            "srsearch": class_name,
            "srlimit": min(limit, 50),
            "format": "json",
        }
        r = safe_request(session, WIKI_API, params=params)
        if not r:
            return []
        data = r.json()
        members = data.get("query", {}).get("search", [])

    count = 0
    for item in members:
        title = item.get("title")
        if not title or not title.lower().startswith("file:"):
            continue

        # Get full image info
        params = {
            "action": "query",
            "prop": "imageinfo|categories",
            "titles": title,
            "iiprop": "url|extmetadata|size",
            "format": "json",
        }
        r = safe_request(session, WIKI_API, params=params)
        if not r:
            continue

        pages = r.json().get("query", {}).get("pages", {})
        if not pages:
            continue
        page = next(iter(pages.values()))

        imageinfo = page.get("imageinfo")
        if not imageinfo:
            continue
        info = imageinfo[0]

        url = info.get("url")
        extmeta = info.get("extmetadata", {})
        license_short = extmeta.get("LicenseShortName", {}).get("value", "")
        license_url = extmeta.get("LicenseUrl", {}).get("value", "")

        license_combined = license_short or license_url
        if not is_license_allowed(license_combined):
            continue

        # Download file
        img_resp = safe_request(session, url)
        if not img_resp:
            continue

        try:
            img_bytes = img_resp.content
            img = Image.open(BytesIO(img_bytes))
            img.verify()
        except Exception:
            continue

        results.append({
            "bytes": img_bytes,
            "url": url,
            "license": license_combined,
            "source": "wikimedia"
        })

        count += 1
        if count >= limit:
            break

        time.sleep(0.25)

    return results


# ------------------------------------------------------------
# MET Museum Downloader
# ------------------------------------------------------------
def download_met_images(class_name: str, limit: int):
    results = []
    session = requests.Session()

    # Step 1: search for object IDs
    r = safe_request(session, MET_SEARCH, params={"q": class_name})
    if not r:
        return results

    ids = r.json().get("objectIDs", []) or []
    if not ids:
        return results

    count = 0
    for oid in ids[:limit]:
        r_obj = safe_request(session, MET_OBJECT + str(oid))
        if not r_obj:
            continue

        obj = r_obj.json()
        if not obj.get("isPublicDomain", False):
            continue

        img_url = obj.get("primaryImage")
        if not img_url:
            continue

        r_img = safe_request(session, img_url)
        if not r_img:
            continue

        try:
            img_bytes = r_img.content
            img = Image.open(BytesIO(img_bytes))
            img.verify()
        except Exception:
            continue

        results.append({
            "bytes": img_bytes,
            "url": img_url,
            "license": "public_domain",
            "source": "met"
        })

        count += 1
        if count >= limit:
            break

        time.sleep(0.2)

    return results


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--classes-file", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--per-class", type=int, default=120)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    # Load class list (35 labels)
    with open(args.classes_file) as f:
        classes = [line.strip() for line in f if line.strip()]

    # provenance log
    prov_path = Path("provenance.csv")
    prov_exists = prov_path.exists()
    prov_f = open(prov_path, "a", newline="", encoding="utf-8")
    writer = csv.writer(prov_f)

    if not prov_exists:
        writer.writerow(["filepath", "class", "url", "license", "source"])

    # Loop through classes
    for cls in classes:
        print(f"\n=== Downloading images for: {cls} ===")
        safe_name = slugify(cls)
        class_dir = out_dir / safe_name
        ensure_dir(class_dir)

        # 1) Wikimedia
        wiki_items = download_wikimedia_images(cls, args.per_class)
        for item in tqdm(wiki_items, desc=f"Wikimedia {cls}"):
            filename = f"{safe_name}_{int(time.time()*1000)}.jpg"
            file_path = class_dir / filename
            save_image_bytes(item["bytes"], file_path)
            writer.writerow([str(file_path), cls, item["url"], item["license"], item["source"]])

        # 2) MET Museum
        met_items = download_met_images(cls, args.per_class)
        for item in tqdm(met_items, desc=f"MET {cls}"):
            filename = f"{safe_name}_{int(time.time()*1000)}_met.jpg"
            file_path = class_dir / filename
            save_image_bytes(item["bytes"], file_path)
            writer.writerow([str(file_path), cls, item["url"], item["license"], item["source"]])

    prov_f.close()
    print("\n[DONE] Download complete. Saved metadata to provenance.csv\n")


if __name__ == "__main__":
    main()

