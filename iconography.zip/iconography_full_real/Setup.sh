#!/usr/bin/env bash
set -e
mkdir -p dataset raw models runs uploads logs
python3 -m venv venv_icono
source venv_icono/bin/activate
pip install --upgrade pip
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
pip install timm ultralytics flask pandas pillow tqdm scikit-learn requests matplotlib ninja
