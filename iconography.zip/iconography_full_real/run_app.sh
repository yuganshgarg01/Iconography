#!/usr/bin/env bash
set -e
source venv_icono/bin/activate
mkdir -p uploads
python3 app.py
