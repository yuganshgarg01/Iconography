#!/usr/bin/env python3
"""
Iconography Web App (Updated)

Key updates:
 - Always load CLASSES from classes.py (hard-coded 35 icons)
 - Ignores checkpoint-saved classes → consistent label mapping
 - Classifier head automatically reshaped for len(CLASSES)
 - Cleaner classifier load, safer error checks
 - YOLO detection logic unchanged
"""

import io
import os
from pathlib import Path
from datetime import datetime
from typing import List

from flask import Flask, request, render_template_string, redirect, url_for, send_from_directory, jsonify
from PIL import Image

import torch
import torch.nn.functional as F
import timm
import torchvision.transforms as T

# ---------------------------------------------------------
# Load 35-class iconography list
# ---------------------------------------------------------
try:
    from classes import CLASSES
except Exception:
    print("ERROR: Could not import CLASSES from classes.py")
    CLASSES = ["unknown"]

print(f"[APP] Loaded {len(CLASSES)} classes.")

# ---------------------------------------------------------
# Optional YOLO detector
# ---------------------------------------------------------
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except Exception:
    YOLO_AVAILABLE = False


# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------
CLS_MODEL_PATH = Path("models/mobilenetv3_best.pth")
DET_MODEL_PATH = Path("runs/detect/exp/weights/best.pt")

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------
# HTML template (unchanged)
# ---------------------------------------------------------
INDEX_HTML = """
<!doctype html>
<title>Iconography Classifier</title>
<style>
body { font-family: Arial; max-width:900px; margin:2rem auto; }
.preview { max-width:300px; border:1px solid #ccc; padding:4px; }
.results { background:#fafafa; padding:1rem; border-radius:8px; margin-top:1rem; }
</style>

<h2>Iconography Classifier</h2>
<p>Upload an image of a sculpture or deity. The system identifies the iconography and explains why.</p>

<form method=post enctype=multipart/form-data action="{{ url_for('analyze') }}">
  <input type=file name=image accept="image/*" required>
  <button type=submit>Analyze</button>
</form>

{% if result %}
<div class="results">
  <h3>Result</h3>
  <img class="preview" src="{{ result.image_url }}">
  <p><b>Final Label:</b> {{ result.final_label }}</p>
  <p><b>Classifier:</b> {{ result.cls_label }} ({{ '%.2f'|format(result.cls_conf) }})</p>
  <p><b>Attributes:</b></p>
  {% if result.attributes %}
    <ul>
    {% for a in result.attributes %}
      <li>{{ a.name }} — {{ '%.2f'|format(a.conf) }}</li>
    {% endfor %}
    </ul>
  {% else %}
    <p><i>No attributes detected</i></p>
  {% endif %}
  <p><b>Explanation:</b> {{ result.explanation }}</p>
  <p style="font-size:0.8em; color:#555;"><b>Trace:</b> {{ result.trace }}</p>
</div>
{% endif %}

<footer style="margin-top:2rem; font-size:0.9em; color:#666;">
Model: {{ cls_path }} — Device: {{ device }}
</footer>
"""

# ---------------------------------------------------------
# Image preprocessing
# ---------------------------------------------------------
def prepare_image(pil_img: Image.Image, input_size: int = 224):
    transform = T.Compose([
        T.Resize(int(input_size * 1.15)),
        T.CenterCrop(input_size),
        T.ToTensor(),
        T.Normalize((0.485,0.456,0.406), (0.229,0.224,0.225)),
    ])
    return transform(pil_img).unsqueeze(0)


# ---------------------------------------------------------
# Fusion rules (unchanged)
# ---------------------------------------------------------
def fusion_rules(classifier_name: str, classifier_conf: float, det_names: List[str]):
    det_set = {n.lower() for n in det_names}

    if any("boar" in n for n in det_set):
        return "varaha", "Boar-head attribute detected"
    if any("lion" in n for n in det_set):
        return "narasimha", "Lion attribute detected"
    if "flute" in det_set or "bansuri" in det_set:
        return "krishna_venugopala", "Flute detected"

    shiva_attr = {"trishula","damaru","jata","crescent_moon","ganga","third_eye"}
    if det_set & shiva_attr:
        return "shiva_standing", "Shiva attributes detected"

    if "chakra" in det_set and "shankha" in det_set:
        return "vishnu_standing", "Chakra + Shankha detected"

    if "lotus" in det_set and classifier_name.startswith("lakshmi"):
        return "lakshmi", "Lotus + classifier support"

    if "mouse" in det_set or "elephant" in det_set:
        return "ganesha_sitting", "Mouse/Elephant indicates Ganesha"

    return classifier_name, "Classifier result kept"


# ---------------------------------------------------------
# Build classifier
# ---------------------------------------------------------
def build_classifier():
    model = timm.create_model(
        "mobilenetv3_large_100",
        pretrained=False,
        num_classes=len(CLASSES)
    )
    return model


# ---------------------------------------------------------
# Load classifier
# ---------------------------------------------------------
print("[APP] Loading classifier model...")

classifier = build_classifier()
if CLS_MODEL_PATH.exists():
    try:
        checkpoint = torch.load(CLS_MODEL_PATH, map_location=DEVICE)
        state_dict = checkpoint.get("model_state_dict", checkpoint)
        classifier.load_state_dict(state_dict, strict=False)
        print("[APP] Classifier loaded.")
    except Exception as e:
        print("[ERROR] Failed to load checkpoint:", e)
else:
    print("[WARNING] No model checkpoint found:", CLS_MODEL_PATH)

classifier = classifier.to(DEVICE)
classifier.eval()

# ---------------------------------------------------------
# Load YOLO detector
# ---------------------------------------------------------
yolo = None
det_exists = False

if YOLO_AVAILABLE and DET_MODEL_PATH.exists():
    try:
        yolo = YOLO(str(DET_MODEL_PATH))
        det_exists = True
        print("[APP] YOLO detector loaded.")
    except Exception as e:
        print("[APP] YOLO load error:", e)


# ---------------------------------------------------------
# Flask
# ---------------------------------------------------------
app = Flask(__name__)


@app.route("/", methods=["GET"])
def index():
    return render_template_string(INDEX_HTML,
                                  result=None,
                                  cls_path=str(CLS_MODEL_PATH),
                                  device=str(DEVICE))


@app.route("/analyze", methods=["POST"])
def analyze():
    uploaded = request.files.get("image")
    if not uploaded:
        return redirect(url_for("index"))

    # Save uploaded file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    fname = f"{timestamp}_{uploaded.filename}"
    saved_path = UPLOAD_DIR / fname

    img_bytes = uploaded.read()
    with open(saved_path, "wb") as f:
        f.write(img_bytes)

    # Open as PIL
    try:
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    except:
        return "Invalid image", 400

    # ---------------------------
    # CLASSIFIER
    # ---------------------------
    cls_label = "unknown"
    cls_conf = 0.0
    trace = []

    try:
        inp = prepare_image(pil_img).to(DEVICE)
        with torch.no_grad():
            out = classifier(inp)
            probs = F.softmax(out, dim=1)[0].cpu().numpy()
            idx = probs.argmax()
            cls_label = CLASSES[idx]
            cls_conf = float(probs[idx])
        trace.append(f"classifier:{cls_label}({cls_conf:.2f})")
    except Exception as e:
        trace.append(f"classifier_error:{e}")

    # ---------------------------
    # DETECTOR
    # ---------------------------
    attributes = []
    det_names = []
    if det_exists and yolo is not None:
        try:
            res = yolo.predict(str(saved_path), imgsz=640, conf=0.25, verbose=False)
            r = res[0]
            boxes = getattr(r, "boxes", None)
            if boxes is not None:
                cls_ids = boxes.cls.cpu().numpy().astype(int).tolist()
                confs = boxes.conf.cpu().numpy().tolist()
                names = [r.names[i] for i in cls_ids]
                for n,c in zip(names, confs):
                    attributes.append({"name": n, "conf": float(c)})
                    det_names.append(n)
            trace.append(f"detection:{len(attributes)}")
        except Exception as e:
            trace.append(f"detection_error:{e}")

    # ---------------------------
    # FUSION
    # ---------------------------
    final_label, reasoning = fusion_rules(cls_label, cls_conf, det_names)
    trace.append(f"fusion:{reasoning}")

    # Explanation
    if attributes:
        attr_text = ", ".join([f"{a['name']}({a['conf']:.2f})" for a in attributes])
        explanation = f"Detected attributes: {attr_text}. "
    else:
        explanation = "No strong attribute detections. "

    explanation += (
        f"Classifier predicted '{cls_label}' ({cls_conf:.2f}). "
        f"Final label: '{final_label}'. Reason: {reasoning}."
    )

    result = {
        "final_label": final_label,
        "cls_label": cls_label,
        "cls_conf": cls_conf,
        "attributes": attributes,
        "explanation": explanation,
        "trace": " | ".join(trace),
        "image_url": f"/uploads/{fname}",
    }

    return render_template_string(INDEX_HTML,
                                  result=result,
                                  cls_path=str(CLS_MODEL_PATH),
                                  device=str(DEVICE))


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(str(UPLOAD_DIR), filename)


# ---------------------------------------------------------
# API endpoint (unchanged)
# ---------------------------------------------------------
@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    if "image" not in request.files:
        return jsonify({"error": "no image"}), 400

    uploaded = request.files["image"]
    img_bytes = uploaded.read()

    try:
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    except:
        return jsonify({"error": "invalid image"}), 400

    inp = prepare_image(pil_img).to(DEVICE)

    with torch.no_grad():
        out = classifier(inp)
        probs = F.softmax(out, dim=1)[0].cpu().numpy()
        idx = probs.argmax()
        cls_label = CLASSES[idx]
        cls_conf = float(probs[idx])

    return jsonify({
        "label": cls_label,
        "confidence": cls_conf
    })


if __name__ == "__main__":
    print("[APP] Starting server...")
    app.run(host="0.0.0.0", port=5000)

