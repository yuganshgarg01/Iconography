#!/usr/bin/env python3
"""
train-model.py
Unified iconography classification + detection training

Major changes:
- Hard-coded class list loaded from classes.py (CLASSES)
- ImageFolder training now uses fixed class ordering
- Checkpoint always stores the same class list
"""

import argparse
import os
import sys
import time
from pathlib import Path
from typing import List

import numpy as np
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms, datasets
import torchvision
import timm

# Multi-label support
import pandas as pd
from sklearn.metrics import f1_score, accuracy_score

# YOLO (optional)
try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except Exception:
    ULTRALYTICS_AVAILABLE = False

# ------------------------------------------------------
# Load hard-coded classes
# ------------------------------------------------------
try:
    from classes import CLASSES
except Exception:
    print("ERROR: Could not import CLASSES from classes.py")
    sys.exit(1)

print(f"[INFO] Loaded {len(CLASSES)} classes from classes.py")

# ------------------------------------------------------
# Utilities
# ------------------------------------------------------
def get_device(prefer_gpu=True):
    if prefer_gpu and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def save_checkpoint(state, path: Path):
    torch.save(state, str(path))


# ------------------------------------------------------
# Multi-label CSV Dataset
# ------------------------------------------------------
class MultiLabelDataset(Dataset):
    """
    CSV format:
    filename, labels
    where 'labels' can be: "durga;kali;shiva"
    """

    def __init__(self, csv_file, img_root, classes, transforms=None, delim=";"):
        self.df = pd.read_csv(csv_file)
        self.img_root = Path(img_root)
        self.transforms = transforms
        self.classes = classes
        self.class_to_idx = {c: i for i, c in enumerate(classes)}
        self.delim = delim

        if "filename" not in self.df or "labels" not in self.df:
            raise ValueError("CSV must contain 'filename' and 'labels' columns")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        img_path = self.img_root / row["filename"]
        img = torchvision.io.read_image(str(img_path)).float() / 255.0
        img = torchvision.transforms.functional.to_pil_image(img)

        if self.transforms:
            img = self.transforms(img)

        raw_labels = str(row["labels"])
        labels = [x.strip() for x in raw_labels.split(self.delim) if x.strip()]

        target = torch.zeros(len(self.classes), dtype=torch.float32)
        for lab in labels:
            if lab in self.class_to_idx:
                target[self.class_to_idx[lab]] = 1.0

        return img, target


# ------------------------------------------------------
# Build Classification Model
# ------------------------------------------------------
def build_classification_model(num_classes, pretrained=True, model_name="mobilenetv3_large_100"):
    return timm.create_model(model_name, pretrained=pretrained, num_classes=num_classes)


# ------------------------------------------------------
# Training (Classification)
# ------------------------------------------------------
def train_classification(args):
    device = get_device(prefer_gpu=not args.cpu)
    print(f"[CLASSIFICATION] Using device: {device}")

    input_size = args.input_size or 224

    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(input_size),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(0.1, 0.1, 0.1, 0.05),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
                             std=(0.229, 0.224, 0.225)),
    ])

    val_tf = transforms.Compose([
        transforms.Resize(int(input_size * 1.15)),
        transforms.CenterCrop(input_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
                             std=(0.229, 0.224, 0.225)),
    ])

    # --------------------------------------------------
    # MULTI-LABEL CSV MODE
    # --------------------------------------------------
    if args.multi_label:
        if not (args.data_csv and args.img_root):
            raise ValueError("Multi-label mode requires --data-csv and --img-root")

        classes = CLASSES
        train_ds = MultiLabelDataset(args.data_csv, args.img_root, classes, transforms=train_tf)

        n = len(train_ds)
        val_n = max(int(0.15 * n), 1)
        train_ds, val_ds = torch.utils.data.random_split(train_ds, [n - val_n, val_n])
        val_ds.dataset.transforms = val_tf

        num_classes = len(CLASSES)
        criterion = nn.BCEWithLogitsLoss()

    # --------------------------------------------------
    # SINGLE-LABEL ImageFolder MODE
    # --------------------------------------------------
    else:
        if not args.data_dir:
            raise ValueError("ImageFolder mode requires --data-dir")

        # We still load dataset for images, but IGNORE its folder-defined classes
        raw_dataset = datasets.ImageFolder(args.data_dir, transform=train_tf)

        # Rewrite targets: map folder names → fixed CLASSES list
        folder_to_label = {}
        for folder_name in raw_dataset.class_to_idx.keys():
            if folder_name not in CLASSES:
                print(f"[WARNING] Folder '{folder_name}' not found in CLASSES; skipping")
            else:
                folder_to_label[raw_dataset.class_to_idx[folder_name]] = CLASSES.index(folder_name)

        # Custom wrapper that remaps targets
        class FixedLabelDataset(Dataset):
            def __init__(self, base):
                self.base = base

            def __len__(self):
                return len(self.base)

            def __getitem__(self, idx):
                img, orig_target = self.base[idx]
                if orig_target in folder_to_label:
                    return img, folder_to_label[orig_target]
                return img, -1  # unused

        fixed_dataset = FixedLabelDataset(raw_dataset)

        # train/val split
        n = len(fixed_dataset)
        val_n = max(int(0.15 * n), 1)
        train_ds, val_ds = torch.utils.data.random_split(fixed_dataset, [n - val_n, val_n])
        val_ds.dataset.base.transform = val_tf

        num_classes = len(CLASSES)
        criterion = nn.CrossEntropyLoss()

    print(f"[CLASSIFICATION] Training on {num_classes} classes")

    # --------------------------------------------------
    # Model, Optimizer
    # --------------------------------------------------
    model = build_classification_model(
        num_classes=num_classes,
        pretrained=not args.no_pretrained,
        model_name=args.model_name
    ).to(device)

    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

    best_metric = -1
    best_path = Path(args.output_dir) / "mobilenetv3_best.pth"
    os.makedirs(args.output_dir, exist_ok=True)

    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == "cuda" and args.amp))

    # --------------------------------------------------
    # TRAINING LOOP
    # --------------------------------------------------
    for epoch in range(1, args.epochs + 1):
        model.train()
        running_loss = 0.0
        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{args.epochs}")

        for imgs, targets in pbar:
            imgs = imgs.to(device)
            targets = targets.to(device)

            optimizer.zero_grad()
            with torch.cuda.amp.autocast(enabled=(device.type == "cuda" and args.amp)):
                out = model(imgs)
                loss = criterion(out, targets)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            pbar.set_postfix({"loss": running_loss / (pbar.n + 1)})

        scheduler.step()

        # ------------------ VALIDATION ------------------
        model.eval()
        preds_all, targets_all = [], []
        with torch.no_grad():
            for imgs, targets in val_loader:
                imgs = imgs.to(device)
                targets = targets.to(device)
                out = model(imgs)

                if args.multi_label:
                    preds = torch.sigmoid(out).cpu().numpy()
                    preds_all.append(preds)
                    targets_all.append(targets.cpu().numpy())
                else:
                    preds = torch.softmax(out, dim=1).argmax(dim=1).cpu().numpy()
                    preds_all.append(preds)
                    targets_all.append(targets.cpu().numpy())

        if args.multi_label:
            y_pred = np.vstack(preds_all)
            y_true = np.vstack(targets_all)
            metric = f1_score((y_pred >= 0.5).astype(int), y_true, average="macro")
        else:
            y_pred = np.concatenate(preds_all)
            y_true = np.concatenate(targets_all)
            metric = accuracy_score(y_true, y_pred)

        print(f"[VAL] Epoch {epoch}: metric = {metric:.4f}")

        if metric > best_metric:
            print(f"[CHECKPOINT] New best metric {metric:.4f} → saving checkpoint")
            best_metric = metric
            save_checkpoint({
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "metric": metric,
                "classes": CLASSES,      # 🔥 always save the 35-class list
            }, best_path)

    print("Training complete. Best metric:", best_metric)
    return best_path


# ------------------------------------------------------
# YOLO Detection Training (unchanged)
# ------------------------------------------------------
def train_detection(args):
    if not ULTRALYTICS_AVAILABLE:
        raise RuntimeError("Ultralytics YOLO not installed")
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    model = YOLO(args.yolo_model)
    return model.train(
        data=args.data_yaml,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch_size,
        device=device
    )


# ------------------------------------------------------
# Argument Parser
# ------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()

    p.add_argument("--mode", choices=["classification", "detection", "both"], default="classification")
    p.add_argument("--data-dir")
    p.add_argument("--data-csv")
    p.add_argument("--img-root")
    p.add_argument("--multi-label", action="store_true")

    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--input-size", type=int, default=224)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--amp", action="store_true")
    p.add_argument("--cpu", action="store_true")
    p.add_argument("--no-pretrained", action="store_true")
    p.add_argument("--model-name", type=str, default="mobilenetv3_large_100")
    p.add_argument("--output-dir", type=str, default="models")

    p.add_argument("--data-yaml")
    p.add_argument("--yolo-model", default="yolov8n.pt")
    p.add_argument("--imgsz", type=int, default=640)

    return p.parse_args()


# ------------------------------------------------------
# MAIN
# ------------------------------------------------------
def main():
    args = parse_args()

    if args.mode in ("classification", "both"):
        ckpt = train_classification(args)
        print("[DONE] Classification saved at:", ckpt)

    if args.mode in ("detection", "both"):
        train_detection(args)


if __name__ == "__main__":
    main()

