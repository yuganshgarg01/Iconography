#!/usr/bin/env bash
set -e
source venv_icono/bin/activate
MODE=${1:-classification}
if [ "$MODE" = "classification" ]; then
    python3 train-model.py --mode classification --data-dir dataset --epochs 40 --batch-size 32 --amp --output-dir models
fi
