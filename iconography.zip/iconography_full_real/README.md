# Full Iconography Project
Contains classifier, detector, dataset downloader, app, and setup tools.
